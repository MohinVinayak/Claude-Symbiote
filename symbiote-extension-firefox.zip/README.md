# Symbiote — Claude Monitor

Symbiote is a sleek, cross-browser extension (Chrome & Firefox) that monitors your Claude.ai generation state and displays it in a beautiful, globally-floating pill on your screen.

Never wonder if Claude has finished writing again! Keep working in your IDE or browsing other tabs while Symbiote keeps you informed.

## Features

- **Global Overlay:** A stunning, dark-themed floating pill injected into every tab.
- **Live Status:** Tracks `Idle`, `Thinking...`, `Writing...`, `Writing code...`, `Error`, and `Done`.
- **Smart "Done" State:** If Claude finishes while you are on another tab, the pill will display "Done" indefinitely until you switch back to the Claude tab, ensuring you never miss a completion.
- **Multi-Tab Support:** Have multiple Claude tabs open? Symbiote intelligently prioritizes actively generating tabs over idle ones.
- **Drag-to-Dismiss (Global Hide):** Click and drag the pill to move it around. Drag it to the bottom "Trash" zone to dismiss it. This hides the pill globally across all tabs!
- **Master Toggle:** Click the Symbiote extension icon in your browser toolbar to instantly hide or show the overlay globally.
- **Click-to-Focus:** Click the pill (without dragging) to instantly jump back to your active Claude tab.
- **Picture-in-Picture (Pop Out):** *(Chrome/Edge/Brave only)* Click the "Pop Out" icon to spawn a real OS-level window that floats over your entire desktop (even over other apps like VS Code or Spotify!).

## Architecture

Symbiote is a 100% pure browser extension built with Manifest V3. It does not require any desktop companion apps to run.

- `content.js`: Injected into `claude.ai` to monitor DOM mutations for generation states.
- `intercept.js`: Injected into `claude.ai`'s `MAIN` world to intercept Server-Sent Events (SSE) for zero-latency chunk detection.
- `background.js`: The central Service Worker that manages global state, handles multi-tab logic, and broadcasts updates.
- `global_ui.js`: Injected into `<all_urls>` to render the Shadow DOM floating pill, drag logic, and PiP window management.

## Installation & Usage

You can download and run Symbiote completely free directly from this repository!

### For Chrome / Edge / Brave
1. Download **`symbiote-extension-chrome.zip`** from the files above and extract it to a folder on your computer.
2. Open Chrome and navigate to `chrome://extensions`.
3. Enable **Developer mode** in the top right corner.
4. Click **Load unpacked** and select the folder you just extracted.
5. Pin the extension to your toolbar, open Claude.ai, and watch the magic happen!

### For Firefox
1. Download **`symbiote-extension-firefox.zip`** from the files above and extract it to a folder.
2. Open Firefox and navigate to `about:debugging`.
3. Click on **This Firefox** in the left menu.
4. Click **Load Temporary Add-on...** and select the `manifest.json` file inside the extracted folder.

*(Note: Firefox requires you to reload temporary add-ons when you restart the browser. For permanent installation, you can download it from the official Firefox Add-ons store once published).*

## Permissions Required
- `tabs`: Used to query open tabs for broadcasting state updates and jumping to the active Claude tab.
- `storage`: Used to persist the global UI visibility state (so if you hide the pill, it stays hidden on reload).
- `alarms`: Used to keep the background service worker alive while Claude is generating.
- `host_permissions`: `<all_urls>` to inject the floating pill everywhere, and `*://*.claude.ai/*` for monitoring generation.
